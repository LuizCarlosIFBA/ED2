import tabelaHashing

arq = open('paises.txt', 'r')  #abre o arquivo
texto = []  #declaro um vetor
matriz = [] #declaro um segundo vetor
texto = arq.readlines() #quebra as linhas do arquivo em vetores 

def gravarMatriz():
    for i in range(len(texto)):          #esse for percorre a posições dp vetor texto
        matriz.append(texto[i].split())  #aqui eu quebro nos espasos das palavras
    arq.close() #comando para fechar o arquivo
    for i in range(len(texto)):          #mostra quedrando em linhas
        print(matriz[i])  
    arq.close() #comando para fechar o arquivo

gravarMatriz()

t = tabelaHashing.HashTable()

t["march 6"] = matriz[0] 
t["march 8"] = matriz[1]
t["march 9"] = matriz[2]
t["march 17"] = matriz[3]

#print(t.arr)

